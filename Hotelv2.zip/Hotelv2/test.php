<?php
session_start( );
$fecha = $_SESSION['date'];
$hoy = date("Y-m-d");

$fecha1 = new DateTime($fecha);//fecha inicial
$fecha2 = new DateTime($hoy);

$intervalo=$fecha2->diff($fecha1);

$res=$intervalo->format('%d dias');

echo $res;

unset($_SESSION['date']);


 ?>
